/*:
 * @plugindesc Bitz Fantasy — subtle hint markers for Map014 clue events
 * @author ASTROLIT GAMES
 * @help Adds a small, softly pulsing marker to clue events 3, 4, 5, 6 and 7 on Map014.
 * Visual-only: does not change event commands, triggers, switches, variables, or puzzle logic.
 */
(function() {
    'use strict';
    var TARGET_MAP_ID = 14;
    var TARGET_EVENT_IDS = [3, 4, 5, 6, 7];
    var _Spriteset_Map_createLowerLayer = Spriteset_Map.prototype.createLowerLayer;
    Spriteset_Map.prototype.createLowerLayer = function() {
        _Spriteset_Map_createLowerLayer.call(this);
        this._bfHintMarkers = [];
        if (!$gameMap || $gameMap.mapId() !== TARGET_MAP_ID) return;
        var self = this;
        TARGET_EVENT_IDS.forEach(function(id) {
            var ev = $gameMap.event(id);
            if (!ev || ev._erased) return;
            var bitmap = new Bitmap(16, 16);
            // RPG Maker MV Bitmap has fillRect, but no standard drawCircle method.
            // Build a small soft diamond using only supported Bitmap operations.
            bitmap.paintOpacity = 22;
            bitmap.fillRect(6, 0, 4, 2, '#f4d98b');
            bitmap.fillRect(3, 2, 10, 2, '#f4d98b');
            bitmap.fillRect(1, 4, 14, 8, '#f4d98b');
            bitmap.fillRect(3, 12, 10, 2, '#f4d98b');
            bitmap.fillRect(6, 14, 4, 2, '#f4d98b');
            bitmap.paintOpacity = 72;
            bitmap.fillRect(7, 3, 2, 10, '#fff0b0');
            bitmap.fillRect(3, 7, 10, 2, '#fff0b0');
            bitmap.paintOpacity = 100;
            bitmap.fillRect(6, 6, 4, 4, '#fff8d9');
            var sprite = new Sprite(bitmap);
            sprite.anchor.x = 0.5;
            sprite.anchor.y = 0.5;
            sprite.z = 7;
            sprite._bfHintEvent = ev;
            sprite._bfHintPhase = id * 0.7;
            self._tilemap.addChild(sprite);
            self._bfHintMarkers.push(sprite);
        });
    };
    var _Spriteset_Map_update = Spriteset_Map.prototype.update;
    Spriteset_Map.prototype.update = function() {
        _Spriteset_Map_update.call(this);
        if (!$gameMap || $gameMap.mapId() !== TARGET_MAP_ID || !this._bfHintMarkers) return;
        var t = Graphics.frameCount || 0;
        this._bfHintMarkers.forEach(function(sprite) {
            var ev = sprite._bfHintEvent;
            if (!ev || ev._erased) { sprite.visible = false; return; }
            sprite.visible = true;
            sprite.x = ev.screenX() + 10;
            sprite.y = ev.screenY() - 27;
            var pulse = (Math.sin(t / 42 + sprite._bfHintPhase) + 1) / 2;
            sprite.opacity = 42 + Math.round(pulse * 28);
            sprite.scale.x = sprite.scale.y = 0.88 + pulse * 0.12;
        });
    };
})();
